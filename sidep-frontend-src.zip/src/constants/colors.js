export const PRIMARY = "#D32F2F";
export const WHITE = "#FFFFFF";
export const ORANGE = "#EF6C00";
export const GREEN = "#00A71B";
export const BLACK = "#000000";