const auxiliar = (props) => props.children;

export default auxiliar;