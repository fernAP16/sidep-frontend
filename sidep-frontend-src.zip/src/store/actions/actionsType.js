export const LOGIN = "LOGIN";
export const LOGOUT = "LOGOUT";
export const SET_DESPACHO = "SET_DESPACHO";