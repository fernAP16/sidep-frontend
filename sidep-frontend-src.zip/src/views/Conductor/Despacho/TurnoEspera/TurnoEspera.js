import React from 'react';
import './TurnoEspera.css';

const TurnoEspera = () => {
  return (
    <div>TurnoEspera</div>
  )
}

export default TurnoEspera;