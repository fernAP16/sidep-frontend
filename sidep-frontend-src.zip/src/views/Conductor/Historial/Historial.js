import React from 'react';
import './Historial.css';

const Historial = () => {
  return (
    <div>Historial</div>
  )
}

export default Historial;