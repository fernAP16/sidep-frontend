export const LOGIN_CONDUCTOR = "/login";
export const INICIO_CONDUCTOR = "/home";
export const HISTORIAL_CONDUCTOR = "/historial";
export const TURNO_ESPERA = "/despacho/turnoEspera";